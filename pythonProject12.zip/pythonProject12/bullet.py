import pygame
from pygame.sprite import Sprite
class Bullet(Sprite):
    def __init__ (self,screen,ship,ai_settings):
        super().__init__()
        self.screen=screen
        self.rect=pygame.Rect(0,0,ai_settings.bullet_width,ai_settings.bullet_height)
        self.rect.centerx=ship.rect.centerx
        self.rect.top=ship.rect.top
        self.y=float(self.rect.y)    #to get exact center
        self.bullet_clr=ai_settings.bullet_clr
        self.bullet_speed=ai_settings.bullet_speed
    def update(self,bullet):
        self.y-=self.bullet_speed
        self.rect.y=self.y
        for newbullet in bullet.copy():
            if newbullet.rect.bottom <= 0:
                bullet.remove(newbullet)
    def draw_bullet(self):
        pygame.draw.rect(self.screen,self.bullet_clr,self.rect)





