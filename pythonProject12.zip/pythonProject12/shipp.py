import pygame
class Ship():
    def __init__ (self,screen,ai_settings):
       self.ai_settings2=ai_settings
       self.screen=screen
       self.image=pygame.image.load('images/ship.bmp')
       self.rect=self.image.get_rect()
       self.screen_rect=screen.get_rect()
       self.rect.centerx=self.screen_rect.centerx
       self.rect.bottom=self.screen_rect.bottom
       self.moving_right=False
       self.moving_left = False
       self.center=float(self.rect.centerx)
       self.rect.centerx=self.center



    def update(self):
        if self.moving_right==True:
          if self.moving_right and self.rect.right < self.screen_rect.right:
           #self.rect.centerx+=1
             self.center+=self.ai_settings2.ship_speed

        if self.moving_left==True:
          if self.moving_left and self.rect.left > 0:
           #self.rect.centerx-=1
             self.center-=self.ai_settings2.ship_speed

        self.rect.centerx=self.center
    def blitme(self):
        self.screen.blit(self.image,self.rect)  #chanched self.rect.centerx to self.center
    def center_ship(self):
        self.center=self.screen_rect.centerx

class Ufo():
    def __init__ (self,screen):
        self.screen=screen
        self.image=pygame.image.load('images/ufo.bmp')
        self.rect=self.image.get_rect()
        self.screen_rect=self.screen.get_rect()
        self.rect.centerx=self.screen_rect.centerx


    def blitme(self,ai_settings):
        image_width = 150
        image_height = 200
        x = (ai_settings.screen_width - image_width) // 2
        y = x = (ai_settings.screen_height - image_height) // 2
        self.screen.blit(self.image,(self.rect.centerx,400))

