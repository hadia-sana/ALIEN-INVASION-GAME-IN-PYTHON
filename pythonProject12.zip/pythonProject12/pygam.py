import sys

import pygame
from set import Settings
from shipp import Ship
from shipp import Ufo
import game_function as gf
from pygame.sprite import Group
from alien import Alien
from Game_stat import stat
from button import Button


def run():
    pygame.init()
    ai_settings = Settings()
    screen=pygame.display.set_mode((ai_settings.screen_height,ai_settings.screen_width))
    pygame.display.set_caption("Alien Invision")
    ship = Ship(screen,ai_settings)
    ufo=Ufo(screen)
    bullet=Group()
    bullet2=Group()
    aliens=Group()
    gf.alien_fleet(ai_settings, screen, aliens,ship)
    statt=stat(ai_settings)
    game_button=Button("play",screen)





    while True:
        gf.check_events(screen,ship,ai_settings,bullet,bullet2,statt,game_button)
        if statt.game_active:
           bullet.update(bullet)
        #gf.alien_fleet(ai_settings,screen,aliens)

        #if len(bullet2) > ai_settings.bullet_allowed:
            #break    #if you wnt to limit the bullets
           gf.alien_update(aliens, ai_settings,bullet,screen,ship,statt)


        gf.update_screen(ai_settings, screen, ship,ufo,bullet,aliens,game_button,statt)

run()


