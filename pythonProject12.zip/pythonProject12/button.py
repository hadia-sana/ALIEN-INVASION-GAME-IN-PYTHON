import pygame.font


class Button():
    def __init__ (self,msg,screen):
        self.height=50
        self.width=200
        self.screen = screen
        self.screen_rect = screen.get_rect()
        self.button_clr=(135, 206, 235)
        self.rect=pygame.Rect(0,0,self.width,self.height)
        self.rect.center=self.screen_rect.center
        self.font=pygame.font.SysFont(None,48)
        self.text_clr=(255,255,255)


        self.prep_msg(msg)


    def prep_msg(self,msg):
        self.img_msg=self.font.render(msg,True,self.text_clr,self.button_clr)
        self.img_msg_rect=self.img_msg.get_rect()
        self.img_msg_rect.center=self.rect.center
    def draw_button(self):
        self.screen.fill(self.button_clr,self.rect)
        self.screen.blit(self.img_msg,self.img_msg_rect)
