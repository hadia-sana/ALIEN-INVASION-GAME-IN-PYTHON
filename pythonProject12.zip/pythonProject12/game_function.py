import sys
import pygame
from bullet import Bullet
from alien import Alien
from time import sleep

def check_keydown_events(event,ship):
    if event.key == pygame.K_RIGHT:
        # ship.rect.centerx+=1
        ship.moving_right = True
    if event.key == pygame.K_LEFT:
        # ship.rect.centerx+=1
        ship.moving_left = True

def check_keyup_events(event,ship):
    if event.key == pygame.K_RIGHT:
        ship.moving_right = False
    if event.key == pygame.K_LEFT:
        ship.moving_left = False
def fire_bullet(ai_settings,screen,ship,bullet,bullet2):
    #if len(bullet)<=ai_settings.bullet_allowed:
        new_bullet=Bullet(screen, ship, ai_settings)
        bullet.add(new_bullet)
        bullet2.add(new_bullet)




def check_events(screen,ship,ai_settings,bullet,bullet2,statt,game_button):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type==pygame.MOUSEBUTTONDOWN:
            mouse_x,mouse_y=pygame.mouse.get_pos()
            check_playbutton(statt, game_button, mouse_x, mouse_y)
        elif event.type==pygame.KEYDOWN:
            if event.key==pygame.K_q:
                sys.exit()
            check_keydown_events(event,ship)
            if event.key==pygame.K_SPACE:
              fire_bullet(ai_settings,screen,ship,bullet,bullet2)


        elif event.type==pygame.KEYUP:
            check_keyup_events(event,ship)
def check_playbutton(statt,game_button,mouse_x,mouse_y):
    if game_button.rect.collidepoint(mouse_x,mouse_y):
        statt.game_active=True



def get_alien_number(ai_settings,alien_width):

    alien_space = (ai_settings.screen_width - (2*alien_width))
    alien_number = int(alien_space/(2*alien_width))
    return alien_number
def get_row_number(ai_settings,alien_height,ship_height):
    alien_space=ai_settings.screen_height-( 3 * alien_height)-ship_height
    alien_row=int(alien_space/(2*alien_height))
    return alien_row
def make_alien(screen,ai_settings,aliens,alien_number,alien_width,alien_height,roww):
    new_alien = Alien(screen, ai_settings)

    new_alien.x = alien_width + (2 * alien_width )* alien_number
    new_alien.rect.y=alien_height+(2*alien_height)*roww
    new_alien.rect.x = new_alien.x
    aliens.add(new_alien)

def alien_fleet(ai_settings,screen,aliens,ship):
   alien=Alien(screen,ai_settings)
   alien_width = alien.rect.width
   alien_height=alien.rect.height
   ship_height=ship.rect.height
   alien_row_number=int(get_row_number(ai_settings,alien_height,ship_height)/2)
   alien_number=get_alien_number(ai_settings,alien_width)
   for row in range(alien_row_number):

     for alien_numberr in range(alien_number):
       make_alien(screen, ai_settings, aliens, alien_numberr, alien_width , alien_height , row)


def change_dir(aliens,ai_settings):
    for alien in aliens.sprites():
        alien.rect.y+=ai_settings.fleet_fall
    ai_settings.fleet_dir*=-1
def change_fleet(aliens,ai_settings):
    for alien in aliens.sprites():
        if alien.check_edge():
            change_dir(aliens, ai_settings)
            break


def update_screen(ai_settings,screen,ship,ufo,bullet,aliens,game_button,statt):
    screen.fill(ai_settings.bg_clr)
    #ufo.blitme(ai_settings)
    ship.blitme()
    ship.update()



    #for alien in aliens.sprites():
        #alien.blitme()
    aliens.draw(screen)

    for bullet in bullet.sprites():
        bullet.draw_bullet()
    if not statt.game_active:
        game_button.draw_button()
    pygame.display.flip()
def check_alien_bullet_collision(aliens,ai_settings,bullet,screen,ship):
    collisions = pygame.sprite.groupcollide(bullet, aliens, True, True)
    if len(aliens)==0:
        bullet.empty()
        alien_fleet(ai_settings, screen, aliens, ship)
def ship_alien_collision(ship,aliens,statt,bullet,ai_settings,screen):
    if pygame.sprite.spritecollideany(ship,aliens):

            print("ship hit")
            #sleep(0.5)
            ship_hit(statt,aliens,bullet,ship,ai_settings,screen)
def check_alien_at_bottom(aliens,statt,bullet,ship,ai_settings,screen):
    for alien in aliens.sprites():
        if alien.rect.bottom >= alien.screen_rect.bottom:
            ship_hit(statt, aliens, bullet, ship, ai_settings, screen)
            break

def alien_update(aliens,ai_settings,bullet,screen,ship,statt):
    aliens.update()

    change_fleet(aliens, ai_settings)
    check_alien_bullet_collision(aliens, ai_settings, bullet, screen, ship)
    ship_alien_collision(ship, aliens, statt, bullet, ai_settings, screen)
    check_alien_at_bottom(aliens, statt, bullet, ship, ai_settings, screen)



    #aliens.check_edge()


def ship_hit(statt,aliens,bullet,ship,ai_settings,screen):

    if statt.ship_left > 0:
      statt.ship_left-=1
      aliens.empty()
      bullet.empty()
      ship.center_ship()
      alien_fleet(ai_settings, screen, aliens, ship)

      sleep(0.5)
    else:
        statt.game_active=False
